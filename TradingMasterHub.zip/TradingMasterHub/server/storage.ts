import { 
  courses, 
  testimonials, 
  resources, 
  contacts,
  type Course, 
  type InsertCourse,
  type Testimonial,
  type InsertTestimonial,
  type Resource,
  type InsertResource,
  type Contact,
  type InsertContact
} from "@shared/schema";

export interface IStorage {
  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  getFreeCourses(): Promise<Course[]>;
  getPremiumCourses(): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;

  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;

  // Resources
  getResources(): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;

  // Contacts
  getContacts(): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
}

export class MemStorage implements IStorage {
  private courses: Map<number, Course>;
  private testimonials: Map<number, Testimonial>;
  private resources: Map<number, Resource>;
  private contacts: Map<number, Contact>;
  private currentCourseId: number;
  private currentTestimonialId: number;
  private currentResourceId: number;
  private currentContactId: number;

  constructor() {
    this.courses = new Map();
    this.testimonials = new Map();
    this.resources = new Map();
    this.contacts = new Map();
    this.currentCourseId = 1;
    this.currentTestimonialId = 1;
    this.currentResourceId = 1;
    this.currentContactId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Sample courses
    const sampleCourses: Course[] = [
      {
        id: 1,
        title: "Complete ICT Market Structure Mastery",
        description: "Learn to identify and trade market structure breaks, change of character, and institutional order flow patterns.",
        category: "Market Structure",
        price: "197.00",
        originalPrice: "297.00",
        duration: "6h 30m",
        lessons: 24,
        students: 1247,
        thumbnail: "https://images.unsplash.com/photo-1642790106117-e829e14a795f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isFree: false,
        isPremium: true,
        videoUrl: "https://example.com/video1",
        level: "intermediate"
      },
      {
        id: 2,
        title: "ICT Trading Fundamentals",
        description: "Perfect introduction to ICT concepts including order blocks, fair value gaps, and basic market structure.",
        category: "Fundamentals",
        price: "0.00",
        originalPrice: null,
        duration: "2h 15m",
        lessons: 8,
        students: 3891,
        thumbnail: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isFree: true,
        isPremium: false,
        videoUrl: "https://example.com/video2",
        level: "beginner"
      },
      {
        id: 3,
        title: "Advanced Smart Money Concepts",
        description: "Deep dive into institutional trading methods, liquidity concepts, and advanced order block analysis.",
        category: "Smart Money",
        price: "397.00",
        originalPrice: "597.00",
        duration: "8h 45m",
        lessons: 32,
        students: 892,
        thumbnail: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isFree: false,
        isPremium: true,
        videoUrl: "https://example.com/video3",
        level: "advanced"
      }
    ];

    const sampleTestimonials: Testimonial[] = [
      {
        id: 1,
        name: "Michael Rodriguez",
        role: "Forex Trader",
        content: "The ICT concepts taught here completely changed my understanding of the markets. I went from losing money to consistent profits within 3 months.",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      },
      {
        id: 2,
        name: "Sarah Chen",
        role: "Stock Trader",
        content: "Finally found a course that explains Smart Money Concepts in a way that actually makes sense. The practical examples are invaluable.",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c8ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      },
      {
        id: 3,
        name: "James Thompson",
        role: "Day Trader",
        content: "Best investment I've made in my trading education. The order block strategies alone have improved my win rate by 40%.",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      }
    ];

    const sampleResources: Resource[] = [
      {
        id: 1,
        title: "ICT Cheat Sheet",
        description: "Quick reference guide covering all essential ICT concepts and terminology",
        type: "pdf",
        downloadUrl: "/downloads/ict-cheat-sheet.pdf",
        icon: "fas fa-file-pdf"
      },
      {
        id: 2,
        title: "Weekly Market Analysis",
        description: "Free weekly videos analyzing current market conditions using ICT concepts",
        type: "video",
        downloadUrl: "/subscribe/weekly-analysis",
        icon: "fas fa-video"
      },
      {
        id: 3,
        title: "Risk Calculator",
        description: "Position sizing tool to help you manage risk effectively on every trade",
        type: "calculator",
        downloadUrl: "/tools/risk-calculator",
        icon: "fas fa-calculator"
      }
    ];

    // Initialize data
    sampleCourses.forEach(course => {
      this.courses.set(course.id, course);
      this.currentCourseId = Math.max(this.currentCourseId, course.id + 1);
    });

    sampleTestimonials.forEach(testimonial => {
      this.testimonials.set(testimonial.id, testimonial);
      this.currentTestimonialId = Math.max(this.currentTestimonialId, testimonial.id + 1);
    });

    sampleResources.forEach(resource => {
      this.resources.set(resource.id, resource);
      this.currentResourceId = Math.max(this.currentResourceId, resource.id + 1);
    });
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async getCoursesByCategory(category: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      course => course.category.toLowerCase() === category.toLowerCase()
    );
  }

  async getFreeCourses(): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(course => course.isFree);
  }

  async getPremiumCourses(): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(course => course.isPremium);
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.currentCourseId++;
    const course: Course = { ...insertCourse, id, students: 0 };
    this.courses.set(id, course);
    return course;
  }

  // Testimonial methods
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.currentTestimonialId++;
    const testimonial: Testimonial = { ...insertTestimonial, id };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  // Resource methods
  async getResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.currentResourceId++;
    const resource: Resource = { ...insertResource, id };
    this.resources.set(id, resource);
    return resource;
  }

  // Contact methods
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: new Date().toISOString() 
    };
    this.contacts.set(id, contact);
    return contact;
  }
}

export const storage = new MemStorage();
