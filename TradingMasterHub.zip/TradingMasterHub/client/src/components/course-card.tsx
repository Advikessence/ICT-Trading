import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Users } from "lucide-react";
import type { Course } from "@shared/schema";

interface CourseCardProps {
  course: Course;
  onEnroll?: (courseId: number) => void;
}

export function CourseCard({ course, onEnroll }: CourseCardProps) {
  const handleEnroll = () => {
    if (onEnroll) {
      onEnroll(course.id);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <Badge
            variant={course.isFree ? "secondary" : "default"}
            className={
              course.isFree
                ? "bg-green-500 text-white"
                : course.isPremium
                ? "bg-primary text-white"
                : "bg-yellow-500 text-slate-900"
            }
          >
            {course.isFree ? "Free" : course.isPremium ? "Premium" : "Standard"}
          </Badge>
        </div>
        <div className="absolute top-4 right-4">
          <Badge variant="secondary" className="bg-black/50 text-white">
            {course.duration}
          </Badge>
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-foreground mb-3 line-clamp-2">
          {course.title}
        </h3>
        <p className="text-muted-foreground mb-4 line-clamp-2">
          {course.description}
        </p>
        <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Play className="h-4 w-4" />
            <span>{course.lessons} Lessons</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{course.students.toLocaleString()} Students</span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {course.isFree ? (
              <span className="text-2xl font-bold text-green-600">Free</span>
            ) : (
              <>
                <span className="text-2xl font-bold text-foreground">
                  ${course.price}
                </span>
                {course.originalPrice && (
                  <span className="text-lg text-muted-foreground line-through">
                    ${course.originalPrice}
                  </span>
                )}
              </>
            )}
          </div>
          <Button
            onClick={handleEnroll}
            className={
              course.isFree
                ? "bg-green-600 hover:bg-green-700 text-white"
                : "gradient-primary text-white hover:opacity-90"
            }
          >
            {course.isFree ? "Start Free" : "Enroll Now"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
