import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Play } from "lucide-react";

interface VideoPlayerProps {
  videoUrl?: string;
  thumbnail: string;
  title: string;
  duration?: string;
}

export function VideoPlayer({ videoUrl, thumbnail, title, duration }: VideoPlayerProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <div className="relative bg-slate-900 rounded-2xl overflow-hidden shadow-2xl cursor-pointer group">
          <img
            src={thumbnail}
            alt={title}
            className="w-full h-auto group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/30 transition-colors">
            <Button
              size="lg"
              className="bg-white/90 hover:bg-white text-foreground w-20 h-20 rounded-full p-0"
            >
              <Play className="h-8 w-8 ml-1" />
            </Button>
          </div>
          {duration && (
            <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded">
              <span className="text-sm">{duration}</span>
            </div>
          )}
        </div>
      </DialogTrigger>
      <DialogContent className="max-w-4xl w-full">
        <div className="aspect-video">
          {videoUrl ? (
            <iframe
              src={videoUrl}
              title={title}
              className="w-full h-full rounded-lg"
              allowFullScreen
            />
          ) : (
            <div className="w-full h-full bg-slate-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Play className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                <p className="text-lg font-semibold text-muted-foreground">
                  Video content would be displayed here
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  {title}
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
