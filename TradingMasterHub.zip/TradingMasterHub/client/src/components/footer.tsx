import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  FaYoutube, 
  FaDiscord, 
  FaTelegram, 
  FaInstagram 
} from "react-icons/fa";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="text-2xl font-bold mb-4">ICT Trading Mastery</h3>
            <p className="text-slate-400 mb-6 max-w-md">
              Empowering traders worldwide with professional ICT education and 
              proven strategies for consistent market success.
            </p>
            <div className="flex gap-4">
              <Button
                variant="outline"
                size="icon"
                className="bg-slate-800 border-slate-700 hover:bg-slate-700"
                asChild
              >
                <a href="#" aria-label="YouTube">
                  <FaYoutube className="h-5 w-5" />
                </a>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="bg-slate-800 border-slate-700 hover:bg-slate-700"
                asChild
              >
                <a href="#" aria-label="Discord">
                  <FaDiscord className="h-5 w-5" />
                </a>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="bg-slate-800 border-slate-700 hover:bg-slate-700"
                asChild
              >
                <a href="#" aria-label="Telegram">
                  <FaTelegram className="h-5 w-5" />
                </a>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="bg-slate-800 border-slate-700 hover:bg-slate-700"
                asChild
              >
                <a href="#" aria-label="Instagram">
                  <FaInstagram className="h-5 w-5" />
                </a>
              </Button>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link href="/courses">
                  <a className="hover:text-white transition-colors">All Courses</a>
                </Link>
              </li>
              <li>
                <a href="#resources" className="hover:text-white transition-colors">
                  Free Resources
                </a>
              </li>
              <li>
                <Link href="/about">
                  <a className="hover:text-white transition-colors">About</a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="hover:text-white transition-colors">Contact</a>
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Community
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-slate-400">
          <p>&copy; 2024 ICT Trading Mastery. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
