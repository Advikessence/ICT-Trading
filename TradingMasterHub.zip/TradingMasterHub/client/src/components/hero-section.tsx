import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function HeroSection() {
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  return (
    <section className="gradient-primary text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Master ICT Trading{" "}
              <span className="text-yellow-400">Concepts</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100 leading-relaxed">
              Learn professional trading strategies from an expert with over 10
              years of market experience. Access premium courses, free resources,
              and live trading sessions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/courses">
                <Button
                  size="lg"
                  className="bg-yellow-500 text-slate-900 hover:bg-yellow-400 font-semibold text-lg px-8 py-4"
                >
                  Start Learning Today
                </Button>
              </Link>
              <Link href="/courses?type=free">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8 py-4"
                >
                  View Free Content
                </Button>
              </Link>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-yellow-400">
                  {stats?.students.toLocaleString() || "5,000+"}
                </div>
                <div className="text-blue-200">Students Taught</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-400">
                  {stats?.courses || "25+"}
                </div>
                <div className="text-blue-200">Courses Created</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-400">
                  {stats?.experience || "10+"}
                </div>
                <div className="text-blue-200">Years Experience</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Professional trading workspace with multiple monitors"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
