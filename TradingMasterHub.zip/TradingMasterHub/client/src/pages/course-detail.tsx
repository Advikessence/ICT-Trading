import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { VideoPlayer } from "@/components/video-player";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Users, 
  Clock, 
  Star, 
  CheckCircle,
  ArrowLeft
} from "lucide-react";
import { Link } from "wouter";
import type { Course } from "@shared/schema";

export default function CourseDetail() {
  const { toast } = useToast();
  const [, params] = useRoute("/courses/:id");
  const courseId = params?.id ? parseInt(params.id) : null;

  const { data: course, isLoading, error } = useQuery<Course>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
  });

  const handleEnrollCourse = () => {
    toast({
      title: "Course Enrollment",
      description: "Enrollment functionality would be implemented here.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-32 mb-8"></div>
            <div className="grid lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2">
                <div className="w-full h-96 bg-slate-200 rounded-2xl mb-8"></div>
                <div className="h-8 bg-slate-200 rounded w-3/4 mb-4"></div>
                <div className="h-4 bg-slate-200 rounded w-full mb-4"></div>
                <div className="h-4 bg-slate-200 rounded w-2/3"></div>
              </div>
              <div>
                <div className="bg-white p-8 rounded-2xl shadow-lg">
                  <div className="h-8 bg-slate-200 rounded mb-4"></div>
                  <div className="h-12 bg-slate-200 rounded mb-6"></div>
                  <div className="h-4 bg-slate-200 rounded mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <div className="text-6xl mb-4">😕</div>
            <h1 className="text-2xl font-bold text-foreground mb-2">
              Course Not Found
            </h1>
            <p className="text-muted-foreground mb-6">
              The course you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/courses">
              <Button>Browse All Courses</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const curriculum = [
    { title: "Introduction to ICT Concepts", duration: "15:30", isPreview: true },
    { title: "Market Structure Basics", duration: "22:45" },
    { title: "Order Blocks Identification", duration: "18:20" },
    { title: "Fair Value Gaps Analysis", duration: "25:15" },
    { title: "Liquidity Sweep Patterns", duration: "20:30" },
    { title: "Entry and Exit Strategies", duration: "28:45" },
    { title: "Risk Management", duration: "16:40" },
    { title: "Live Trading Examples", duration: "35:20" },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <Link href="/courses">
          <Button variant="ghost" className="mb-8">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Courses
          </Button>
        </Link>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="mb-8">
              <VideoPlayer
                videoUrl={course.videoUrl}
                thumbnail={course.thumbnail}
                title={course.title}
                duration={course.duration}
              />
            </div>

            {/* Course Info */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Badge
                  variant={course.isFree ? "secondary" : "default"}
                  className={
                    course.isFree
                      ? "bg-green-500 text-white"
                      : course.isPremium
                      ? "bg-primary text-white"
                      : "bg-yellow-500 text-slate-900"
                  }
                >
                  {course.isFree ? "Free" : course.isPremium ? "Premium" : "Standard"}
                </Badge>
                <Badge variant="outline">{course.level}</Badge>
                <Badge variant="outline">{course.category}</Badge>
              </div>
              <h1 className="text-4xl font-bold text-foreground mb-4">
                {course.title}
              </h1>
              <p className="text-xl text-muted-foreground mb-6">
                {course.description}
              </p>
              <div className="flex items-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Play className="h-4 w-4" />
                  <span>{course.lessons} Lessons</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>{course.students.toLocaleString()} Students</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>4.9 (245 reviews)</span>
                </div>
              </div>
            </div>

            {/* Course Curriculum */}
            <Card>
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold text-foreground mb-6">
                  Course Curriculum
                </h2>
                <div className="space-y-4">
                  {curriculum.map((lesson, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg">
                          <Play className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-medium">{lesson.title}</span>
                        {lesson.isPreview && (
                          <Badge variant="outline" className="text-xs">
                            Preview
                          </Badge>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {lesson.duration}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div>
            <Card className="sticky top-24">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  {course.isFree ? (
                    <div className="text-3xl font-bold text-green-600 mb-2">
                      Free
                    </div>
                  ) : (
                    <div className="mb-2">
                      <div className="text-3xl font-bold text-foreground">
                        ${course.price}
                      </div>
                      {course.originalPrice && (
                        <div className="text-lg text-muted-foreground line-through">
                          ${course.originalPrice}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <Button
                  size="lg"
                  className={`w-full mb-6 ${
                    course.isFree
                      ? "bg-green-600 hover:bg-green-700 text-white"
                      : "gradient-primary text-white hover:opacity-90"
                  }`}
                  onClick={handleEnrollCourse}
                >
                  {course.isFree ? "Start Free Course" : "Enroll Now"}
                </Button>

                <div className="space-y-4 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Lifetime access</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Certificate of completion</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Mobile and desktop access</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Community support</span>
                  </div>
                  {!course.isFree && (
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>30-day money-back guarantee</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
