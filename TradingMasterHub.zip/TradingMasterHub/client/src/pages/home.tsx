import { useQuery } from "@tanstack/react-query";
import { HeroSection } from "@/components/hero-section";
import { TestimonialsSection } from "@/components/testimonials";
import { CourseCard } from "@/components/course-card";
import { VideoPlayer } from "@/components/video-player";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { 
  TrendingUp, 
  Target, 
  Crosshair, 
  Brain, 
  Play, 
  Users,
  CheckCircle,
  FileText,
  Video,
  Calculator,
  Mail,
  Clock,
  MessageCircle
} from "lucide-react";
import type { Course, Resource } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: resources = [] } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  const featuredCourses = courses.slice(0, 3);

  const handleEnrollCourse = (courseId: number) => {
    toast({
      title: "Course Enrollment",
      description: "Enrollment functionality would be implemented here.",
    });
  };

  const handleResourceAction = (resource: Resource) => {
    toast({
      title: `${resource.title}`,
      description: `${resource.type} resource access would be implemented here.`,
    });
  };

  const categories = [
    {
      icon: TrendingUp,
      title: "Market Structure",
      description: "Understanding market dynamics, trend analysis, and structural patterns",
      courses: 8,
      color: "bg-primary/10 text-primary"
    },
    {
      icon: Target,
      title: "Smart Money Concepts",
      description: "Learn how institutional traders move the market and follow their footsteps",
      courses: 12,
      color: "bg-green-100 text-green-600"
    },
    {
      icon: Crosshair,
      title: "Order Blocks & FVG",
      description: "Master order blocks, fair value gaps, and institutional order flow",
      courses: 6,
      color: "bg-yellow-100 text-yellow-600"
    },
    {
      icon: Brain,
      title: "Trading Psychology",
      description: "Develop the mindset and discipline required for consistent profitability",
      courses: 4,
      color: "bg-purple-100 text-purple-600"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Course Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              Featured Course Categories
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive ICT trading education covering all essential concepts 
              from beginner to advanced levels
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((category, index) => {
              const IconComponent = category.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 ${category.color}`}>
                      <IconComponent className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {category.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {category.description}
                    </p>
                    <div className="flex items-center text-sm text-primary font-medium">
                      <span>{category.courses} Courses</span>
                      <TrendingUp className="ml-2 h-4 w-4" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-4">
                Featured Courses
              </h2>
              <p className="text-xl text-muted-foreground">
                Start your ICT trading journey with these comprehensive courses
              </p>
            </div>
            <div className="hidden md:flex gap-4">
              <Link href="/courses">
                <Button variant="outline">All Courses</Button>
              </Link>
              <Link href="/courses?type=free">
                <Button className="bg-green-600 hover:bg-green-700 text-white">
                  Free Only
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {featuredCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onEnroll={handleEnrollCourse}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/courses">
              <Button size="lg" className="gradient-secondary text-white">
                View All Courses
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Video Preview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6">
                Get a Preview of My Teaching Style
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Watch this free lesson to understand how I break down complex ICT concepts 
                into easy-to-understand actionable strategies.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  "Step-by-step visual explanations",
                  "Real market examples and case studies",
                  "Practical application techniques"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="bg-green-100 p-2 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              <Link href="/courses?type=free">
                <Button size="lg" className="gradient-primary text-white">
                  Access Free Lessons
                </Button>
              </Link>
            </div>
            <div className="relative">
              <VideoPlayer
                thumbnail="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450"
                title="ICT Trading Fundamentals Preview"
                duration="15:32"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <TestimonialsSection />

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
                alt="Professional trader in business attire at trading desk"
                className="rounded-2xl shadow-2xl"
              />
            </div>
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6">
                About Your Instructor
              </h2>
              <p className="text-xl text-muted-foreground mb-6">
                With over 10 years of professional trading experience and a proven 
                track record of consistent profitability, I've dedicated my career to 
                mastering and teaching ICT (Inner Circle Trader) concepts.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  {
                    icon: Brain,
                    title: "Professional Background",
                    description: "Former institutional trader with experience at major financial firms",
                    color: "bg-primary/10 text-primary"
                  },
                  {
                    icon: TrendingUp,
                    title: "Trading Expertise",
                    description: "Specialized in Forex, Indices, and Commodities using ICT methodology",
                    color: "bg-green-100 text-green-600"
                  },
                  {
                    icon: Users,
                    title: "Teaching Impact",
                    description: "Helped over 5,000 traders improve their market understanding and profitability",
                    color: "bg-yellow-100 text-yellow-600"
                  }
                ].map((item, index) => {
                  const IconComponent = item.icon;
                  return (
                    <div key={index} className="flex items-start gap-4">
                      <div className={`p-2 rounded-lg mt-1 ${item.color}`}>
                        <IconComponent className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
              <Link href="/about">
                <Button size="lg" className="gradient-primary text-white">
                  Learn More About My Journey
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Free Resources */}
      <section id="resources" className="py-20 bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              Free Trading Resources
            </h2>
            <p className="text-xl text-muted-foreground">
              Get started with these complimentary materials and tools
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {resources.map((resource) => {
              const getIcon = (type: string) => {
                switch (type) {
                  case "pdf":
                    return FileText;
                  case "video":
                    return Video;
                  case "calculator":
                    return Calculator;
                  default:
                    return FileText;
                }
              };
              
              const IconComponent = getIcon(resource.type);
              const getColor = (type: string) => {
                switch (type) {
                  case "pdf":
                    return "bg-primary/10 text-primary";
                  case "video":
                    return "bg-green-100 text-green-600";
                  case "calculator":
                    return "bg-yellow-100 text-yellow-600";
                  default:
                    return "bg-primary/10 text-primary";
                }
              };

              const getButtonColor = (type: string) => {
                switch (type) {
                  case "pdf":
                    return "gradient-primary text-white hover:opacity-90";
                  case "video":
                    return "bg-green-600 hover:bg-green-700 text-white";
                  case "calculator":
                    return "bg-yellow-500 hover:bg-yellow-600 text-slate-900";
                  default:
                    return "gradient-primary text-white hover:opacity-90";
                }
              };

              const getButtonText = (type: string) => {
                switch (type) {
                  case "pdf":
                    return "Download Free PDF";
                  case "video":
                    return "Subscribe for Free";
                  case "calculator":
                    return "Use Calculator";
                  default:
                    return "Get Resource";
                }
              };

              return (
                <Card key={resource.id} className="hover:shadow-xl transition-shadow">
                  <CardContent className="p-8">
                    <div className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 ${getColor(resource.type)}`}>
                      <IconComponent className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {resource.title}
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      {resource.description}
                    </p>
                    <Button
                      className={`w-full ${getButtonColor(resource.type)}`}
                      onClick={() => handleResourceAction(resource)}
                    >
                      {getButtonText(resource.type)}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Preview */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-6">Ready to Start Your Trading Journey?</h2>
            <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
              Have questions about the courses or need personalized guidance? 
              I'm here to help you succeed in your trading journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
              <div className="flex items-center gap-3">
                <div className="bg-primary/20 p-3 rounded-lg">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">Email</div>
                  <div className="text-slate-300">hello@icttrading.com</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-primary/20 p-3 rounded-lg">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">Response Time</div>
                  <div className="text-slate-300">Usually within 24 hours</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-primary/20 p-3 rounded-lg">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">Discord Community</div>
                  <div className="text-slate-300">Join 2,000+ active traders</div>
                </div>
              </div>
            </div>
            <Link href="/contact">
              <Button size="lg" className="gradient-primary text-white">
                Get In Touch
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
