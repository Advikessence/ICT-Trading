import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  TrendingUp, 
  Users, 
  Brain, 
  Award, 
  BookOpen, 
  Target,
  CheckCircle
} from "lucide-react";

export default function About() {
  const achievements = [
    { number: "10+", text: "Years Trading Experience" },
    { number: "5,000+", text: "Students Taught" },
    { number: "25+", text: "Courses Created" },
    { number: "92%", text: "Student Success Rate" },
  ];

  const expertise = [
    {
      icon: TrendingUp,
      title: "Market Structure Analysis",
      description: "Expert in identifying institutional footprints and market manipulation patterns"
    },
    {
      icon: Target,
      title: "Smart Money Concepts",
      description: "Deep understanding of how banks and institutions move the markets"
    },
    {
      icon: Brain,
      title: "Trading Psychology",
      description: "Helping traders develop the right mindset for consistent profitability"
    },
    {
      icon: Award,
      title: "Risk Management",
      description: "Teaching proper position sizing and capital preservation techniques"
    }
  ];

  const timeline = [
    {
      year: "2014",
      title: "Started Professional Trading",
      description: "Began career at a major financial institution trading forex and commodities"
    },
    {
      year: "2017",
      title: "Discovered ICT Concepts",
      description: "Found the missing pieces that transformed my trading approach completely"
    },
    {
      year: "2019",
      title: "Started Teaching",
      description: "Launched first course to share ICT knowledge with retail traders"
    },
    {
      year: "2021",
      title: "Full-Time Educator",
      description: "Transitioned to focus entirely on education and helping others succeed"
    },
    {
      year: "2024",
      title: "5000+ Students",
      description: "Reached milestone of helping over 5,000 traders worldwide"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Section */}
      <section className="gradient-primary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                About Your <span className="text-yellow-400">ICT Trading</span> Instructor
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-blue-100 leading-relaxed">
                Transforming traders worldwide through proven ICT concepts and 
                institutional-level market analysis.
              </p>
              <Link href="/contact">
                <Button size="lg" className="bg-yellow-500 text-slate-900 hover:bg-yellow-400 font-semibold">
                  Get In Touch
                </Button>
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
                alt="Professional trader at trading desk"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {achievements.map((achievement, index) => (
              <div key={index} className="p-6">
                <div className="text-4xl font-bold text-primary mb-2">
                  {achievement.number}
                </div>
                <div className="text-muted-foreground">
                  {achievement.text}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">My Trading Journey</h2>
            <p className="text-xl text-muted-foreground">
              From struggling retail trader to successful educator
            </p>
          </div>
          <div className="prose prose-lg max-w-none">
            <Card>
              <CardContent className="p-8">
                <p className="text-lg text-muted-foreground mb-6">
                  Like many traders, I started my journey with traditional technical analysis, 
                  losing money consistently for years. The turning point came when I discovered 
                  ICT (Inner Circle Trader) concepts and began understanding how institutional 
                  traders really move the markets.
                </p>
                <p className="text-lg text-muted-foreground mb-6">
                  After years of refining my approach and achieving consistent profitability, 
                  I realized that this knowledge needed to be shared. Too many retail traders 
                  were struggling with the same issues I once faced, using outdated methods 
                  that simply don't work against institutional algorithms.
                </p>
                <p className="text-lg text-muted-foreground">
                  Today, I'm passionate about teaching these concepts in a clear, practical way 
                  that helps traders at every level understand what's really happening in the 
                  markets. My goal is to bridge the gap between institutional knowledge and 
                  retail trading success.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Areas of Expertise</h2>
            <p className="text-xl text-muted-foreground">
              Specialized knowledge that makes the difference
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {expertise.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="bg-primary/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Professional Timeline</h2>
            <p className="text-xl text-muted-foreground">
              Key milestones in my trading and education journey
            </p>
          </div>
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-primary/20"></div>
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                    <Card>
                      <CardContent className="p-6">
                        <Badge className="mb-3">{item.year}</Badge>
                        <h3 className="text-xl font-semibold text-foreground mb-2">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground">
                          {item.description}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="relative z-10 w-6 h-6 bg-primary rounded-full border-4 border-white"></div>
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Teaching Philosophy */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6">
                My Teaching Philosophy
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Education should be practical, clear, and immediately applicable. 
                I focus on teaching concepts that actually work in real market conditions.
              </p>
              <div className="space-y-4">
                {[
                  "No-nonsense approach to complex concepts",
                  "Real market examples over theoretical knowledge",
                  "Focus on risk management and psychology",
                  "Building traders, not just selling courses",
                  "Continuous support and community building"
                ].map((principle, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-muted-foreground">{principle}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
                alt="Teaching trading concepts"
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Learn From Experience?</h2>
          <p className="text-xl text-slate-300 mb-8">
            Join thousands of traders who've transformed their approach to the markets 
            through proven ICT concepts and institutional analysis.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/courses">
              <Button size="lg" className="gradient-primary text-white">
                View All Courses
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-slate-900">
                Get Personal Guidance
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
